import React, { useEffect, useState } from "react";
import { useParams } from "react-router";
import axios from "axios";
import { Link } from "react-router-dom";

const Detalle = () => {
  const [factura, setFactura] = useState({});
  const { id } = useParams();

  useEffect(() => {
    axios
      .get("http://localhost:8000/facturas/" + id)
      .then((res) => setFactura(res.data));
  }, [id]);

  return (
    <div>
      <ul>
        <li>{factura.cliente}</li>
      </ul>
    </div>
  );
};

export default Detalle;
